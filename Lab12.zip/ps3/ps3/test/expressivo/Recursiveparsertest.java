package expressivo;


import org.junit.Test;

/**
 * Tests for the Recursiveparser class that evaluates mathematical expressions.
 */
public class Recursiveparsertest {

// Test Case 1: Invalid parentheses (unmatched parentheses)
@Test(expected = IllegalArgumentException.class)
public void testInvalidParenthesesUnmatched() {
    String expression = "5 * (3 + 2";
    Recursiveparser.evaluateExpression(expression);
}

// Test Case 2: Missing parentheses in complex expression
@Test(expected = IllegalArgumentException.class)
public void testMissingParentheses() {
    String expression = "3 + 5 * (2 + 3";
    Recursiveparser.evaluateExpression(expression);
}


// Test Case 3: Invalid expression (extra operator)
@Test(expected = IllegalArgumentException.class)
public void testInvalidExpressionExtraOperator() {
    String expression = "5 + * 3";
    Recursiveparser.evaluateExpression(expression);
}


// Test Case 4: Invalid expression (trailing operator)
@Test(expected = IllegalArgumentException.class)
public void testTrailingOperator() {
    String expression = "3 + 5 +";
    Recursiveparser.evaluateExpression(expression);
}


// Test Case 5: Invalid number format (non-numeric input)
@Test(expected = IllegalArgumentException.class)
public void testInvalidNumberFormat() {
    String expression = "5 + x";
    Recursiveparser.evaluateExpression(expression);
}


    // Test Case 7: Division by zero should throw an ArithmeticException
    @Test(expected = ArithmeticException.class)
    public void testDivisionByZero() {
        String expression = "5 / 0";
        Recursiveparser.evaluateExpression(expression);
    }

    // Test Case 8: Invalid expression (missing operator)
    @Test(expected = IllegalArgumentException.class)
    public void testInvalidExpressionMissingOperator() {
        String expression = "5 5 +";
        Recursiveparser.evaluateExpression(expression);
    }

// Test Case 9: Expression with non-numeric characters
@Test(expected = IllegalArgumentException.class)
public void testNonNumericCharacters() {
    String expression = "3 + 2 & 5";
    Recursiveparser.evaluateExpression(expression);
}



}
