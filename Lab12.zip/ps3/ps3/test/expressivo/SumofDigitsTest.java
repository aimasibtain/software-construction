package expressivo;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SumofDigitsTest {

    // Test Case 1: Sum of digits of 0 (Edge Case)
    @Test
    public void testSumOfDigitsZero() {
        int number = 0;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 0 should be 0", 0, result);
    }

    // Test Case 2: Sum of digits of a single-digit positive number
    @Test
    public void testSumOfDigitsSingleDigit() {
        int number = 5;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 5 should be 5", 5, result);
    }

    // Test Case 3: Sum of digits of a multi-digit positive number
    @Test
    public void testSumOfDigitsMultipleDigits() {
        int number = 123;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 123 should be 6", 6, result);
    }

    // Test Case 4: Sum of digits of a large positive number
    @Test
    public void testSumOfDigitsLargeNumber() {
        int number = 987654321;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 987654321 should be 45", 45, result);
    }

    // Test Case 5: Sum of digits of a negative number
    @Test
    public void testSumOfDigitsNegativeNumber() {
        int number = -54321;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of -54321 should be 15", 15, result);
    }

   

    // Test Case 7: Sum of digits of a number with all identical digits (e.g., 1111)
    @Test
    public void testSumOfDigitsIdenticalDigits() {
        int number = 1111;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 1111 should be 4", 4, result);
    }

    // Test Case 8: Sum of digits of a number with leading zeros (e.g., 000123)
    @Test
    public void testSumOfDigitsWithLeadingZeros() {
        int number = 123;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 123 should be 6", 6, result);
    }

    // Test Case 9: Sum of digits of a number with alternating digits (e.g., 123456789)
    @Test
    public void testSumOfDigitsAlternatingDigits() {
        int number = 123456789;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of 123456789 should be 45", 45, result);
    }

    // Test Case 10: Sum of digits of a very large number
    @Test
    public void testSumOfDigitsLargeValue() {
        int number = Integer.MAX_VALUE;
        int result = SumOfDigits.sumOfDigits(number);
        assertEquals("Sum of digits of Integer.MAX_VALUE should be 46", 46, result);
    }

}
