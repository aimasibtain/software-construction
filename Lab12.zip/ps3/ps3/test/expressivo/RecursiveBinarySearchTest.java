package expressivo;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.List;

public class RecursiveBinarySearchTest {

    // Test Case 1: Single occurrence of target in integer array
    @Test
    public void testBinarySearchIntegerTargetFound() {
        int[] intArr = {1, 3, 5, 7, 9, 11, 15, 18, 20};
        int result = RecursiveBinarySearch.binarySearchRecursive(intArr, 9);
        assertEquals("Index of 9 should be 4.", 4, result);
    }

    // Test Case 2: Target not found in integer array
    @Test
    public void testBinarySearchIntegerTargetNotFound() {
        int[] intArr = {1, 3, 5, 7, 9, 11, 15, 18, 20};
        int result = RecursiveBinarySearch.binarySearchRecursive(intArr, 6);
        assertEquals("Index of 6 should be -1 as it's not in the array.", -1, result);
    }

    // Test Case 4: Target not found in integer array with multiple occurrences
    @Test
    public void testBinarySearchIntegerNoTargetFound() {
        int[] intArr = {1, 3, 3, 5, 7, 9, 9, 9, 11};
        List<Integer> result = RecursiveBinarySearch.binarySearchAllIndices(intArr, 6);
        assertTrue("There should be no occurrences of 6.", result.isEmpty());
    }

    // Test Case 5: Single occurrence of target in string array
    @Test
    public void testBinarySearchStringTargetFound() {
        String[] strArr = {"apple", "banana", "cherry", "date", "fig", "grape"};
        int result = RecursiveBinarySearch.binarySearchRecursive(strArr, "cherry");
        assertEquals("Index of 'cherry' should be 2.", 2, result);
    }

    // Test Case 6: Target not found in string array
    @Test
    public void testBinarySearchStringTargetNotFound() {
        String[] strArr = {"apple", "banana", "cherry", "date", "fig", "grape"};
        int result = RecursiveBinarySearch.binarySearchRecursive(strArr, "kiwi");
        assertEquals("Index of 'kiwi' should be -1 as it's not in the array.", -1, result);
    }

    // Test Case 8: Edge case - Empty integer array
    @Test
    public void testBinarySearchEmptyIntegerArray() {
        int[] emptyIntArr = {};
        int result = RecursiveBinarySearch.binarySearchRecursive(emptyIntArr, 5);
        assertEquals("Index in empty array should be -1.", -1, result);
    }

    // Test Case 9: Edge case - Null integer array
    @Test
    public void testBinarySearchNullIntegerArray() {
        int[] nullIntArr = null;
        int result = RecursiveBinarySearch.binarySearchRecursive(nullIntArr, 5);
        assertEquals("Index in null array should be -1.", -1, result);
    }

    // Test Case 10: Edge case - Empty string array
    @Test
    public void testBinarySearchEmptyStringArray() {
        String[] emptyStrArr = {};
        int result = RecursiveBinarySearch.binarySearchRecursive(emptyStrArr, "banana");
        assertEquals("Index in empty array should be -1.", -1, result);
    }

    // Test Case 11: Edge case - Null string array
    @Test
    public void testBinarySearchNullStringArray() {
        String[] nullStrArr = null;
        int result = RecursiveBinarySearch.binarySearchRecursive(nullStrArr, "banana");
        assertEquals("Index in null array should be -1.", -1, result);
    }

    // Test Case 12: Edge case - Target at the beginning of string array
    @Test
    public void testBinarySearchStringTargetAtBeginning() {
        String[] strArr = {"apple", "banana", "cherry", "date", "fig", "grape"};
        int result = RecursiveBinarySearch.binarySearchRecursive(strArr, "apple");
        assertEquals("Index of 'apple' should be 0.", 0, result);
    }

    // Test Case 13: Edge case - Target at the end of string array
    @Test
    public void testBinarySearchStringTargetAtEnd() {
        String[] strArr = {"apple", "banana", "cherry", "date", "fig", "grape"};
        int result = RecursiveBinarySearch.binarySearchRecursive(strArr, "grape");
        assertEquals("Index of 'grape' should be 5.", 5, result);
    }
}
