package expressivo;
import java.util.Scanner;

public class SumOfDigits {

    // Recursive function to compute the sum of digits
    public static int sumOfDigits(int num) {
        // Handle negative numbers by converting them to positive
        num = Math.abs(num);

        // Base case: If the number is 0, return 0
        if (num == 0) {
            return 0;
        }

        // Recursive case: Add the last digit to the sum of the remaining digits
        return num % 10 + sumOfDigits(num / 10);
    }

    // Main method to take input and display the result
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a non-negative integer (can also handle negative numbers): ");
        
        // Read the input number
        int number = scanner.nextInt();
        
        // Calculate the sum of digits using the recursive function
        int result = sumOfDigits(number);
        
        // Display the result
        System.out.println("The sum of digits of " + number + " is: " + result);
        
        scanner.close();
    }
}
