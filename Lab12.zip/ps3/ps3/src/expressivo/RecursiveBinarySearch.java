/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package expressivo;
import java.util.ArrayList;
import java.util.List;

public class RecursiveBinarySearch {

    // Recursive binary search for integers
    public static int binarySearchRecursive(int[] arr, int target) {
        if (arr == null || arr.length == 0) {
            return -1; // Edge case: array is null or empty
        }
        return binarySearchRecursiveHelper(arr, target, 0, arr.length - 1);
    }

    // Helper method for the recursive binary search (for integers)
    private static int binarySearchRecursiveHelper(int[] arr, int target, int left, int right) {
        if (left > right) {
            return -1; // Base case: target not found
        }
        
        int mid = left + (right - left) / 2;
        
        if (arr[mid] == target) {
            return mid; // Base case: found the target
        }
        
        if (arr[mid] > target) {
            return binarySearchRecursiveHelper(arr, target, left, mid - 1); // Search left half
        } else {
            return binarySearchRecursiveHelper(arr, target, mid + 1, right); // Search right half
        }
    }

    // Recursive binary search for strings
    public static int binarySearchRecursive(String[] arr, String target) {
        if (arr == null || arr.length == 0) {
            return -1; // Edge case: array is null or empty
        }
        return binarySearchRecursiveHelper(arr, target, 0, arr.length - 1);
    }

    // Helper method for the recursive binary search (for strings)
    private static int binarySearchRecursiveHelper(String[] arr, String target, int left, int right) {
        if (left > right) {
            return -1; // Base case: target not found
        }

        int mid = left + (right - left) / 2;

        if (arr[mid].equals(target)) {
            return mid; // Base case: found the target
        }

        if (arr[mid].compareTo(target) > 0) {
            return binarySearchRecursiveHelper(arr, target, left, mid - 1); // Search left half
        } else {
            return binarySearchRecursiveHelper(arr, target, mid + 1, right); // Search right half
        }
    }

    // Recursive binary search to find all indices of the target value
    public static List<Integer> binarySearchAllIndices(int[] arr, int target) {
        List<Integer> result = new ArrayList<>();
        if (arr != null && arr.length > 0) {
            binarySearchAllIndicesHelper(arr, target, 0, arr.length - 1, result);
        }
        return result;
    }

    // Helper method to find all indices for an integer target
    private static void binarySearchAllIndicesHelper(int[] arr, int target, int left, int right, List<Integer> result) {
        if (left > right) {
            return;
        }

        int mid = left + (right - left) / 2;

        if (arr[mid] == target) {
            result.add(mid); // Target found, add index to result
            // Search left and right for more occurrences
            binarySearchAllIndicesHelper(arr, target, left, mid - 1, result);
            binarySearchAllIndicesHelper(arr, target, mid + 1, right, result);
        } else if (arr[mid] > target) {
            binarySearchAllIndicesHelper(arr, target, left, mid - 1, result); // Search left half
        } else {
            binarySearchAllIndicesHelper(arr, target, mid + 1, right, result); // Search right half
        }
    }

    // Recursive binary search to find all indices of the target value in strings
    public static List<Integer> binarySearchAllIndices(String[] arr, String target) {
        List<Integer> result = new ArrayList<>();
        if (arr != null && arr.length > 0) {
            binarySearchAllIndicesHelper(arr, target, 0, arr.length - 1, result);
        }
        return result;
    }

    // Helper method to find all indices for a string target
    private static void binarySearchAllIndicesHelper(String[] arr, String target, int left, int right, List<Integer> result) {
        if (left > right) {
            return;
        }

        int mid = left + (right - left) / 2;

        if (arr[mid].equals(target)) {
            result.add(mid); // Target found, add index to result
            // Search left and right for more occurrences
            binarySearchAllIndicesHelper(arr, target, left, mid - 1, result);
            binarySearchAllIndicesHelper(arr, target, mid + 1, right, result);
        } else if (arr[mid].compareTo(target) > 0) {
            binarySearchAllIndicesHelper(arr, target, left, mid - 1, result); // Search left half
        } else {
            binarySearchAllIndicesHelper(arr, target, mid + 1, right, result); // Search right half
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        // Integer test
        int[] intArr = {1, 3, 3, 5, 7, 9, 9, 9, 11};
        System.out.println("Index of 9: " + binarySearchRecursive(intArr, 9)); // Expected: 5
        System.out.println("All indices of 9: " + binarySearchAllIndices(intArr, 9)); // Expected: [5, 6, 7]

        // String test
        String[] strArr = {"apple", "banana", "cherry", "cherry", "date", "fig", "grape"};
        System.out.println("Index of 'cherry': " + binarySearchRecursive(strArr, "cherry")); // Expected: 2
        System.out.println("All indices of 'cherry': " + binarySearchAllIndices(strArr, "cherry")); // Expected: [2, 3]
    }
}
