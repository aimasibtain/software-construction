package expressivo;

import java.util.*;

public class Recursiveparser {

    private static final Set<Character> OPERATORS = new HashSet<>(Arrays.asList('+', '-', '*', '/'));

    // Main function to evaluate the expression
    public static double evaluateExpression(String expression) {
        expression = expression.replaceAll("\\s", ""); // Remove whitespace for easier parsing
        return evaluateAddSub(expression, 0).result;
    }

    // Helper method to evaluate addition and subtraction (higher level of recursion)
    private static Result evaluateAddSub(String expression, int startIndex) {
        double result = 0;
        double currentTerm = 0;
        char operator = '+';
        int i = startIndex;

        while (i < expression.length()) {
            char ch = expression.charAt(i);

            if (ch == '+' || ch == '-') {
                operator = ch;
                i++;
            }

            // First, evaluate multiplication/division (higher precedence)
            Result termResult = evaluateMulDiv(expression, i);
            currentTerm = termResult.result;
            i = termResult.index;

            // Perform the current operation
            if (operator == '+') {
                result += currentTerm;
            } else if (operator == '-') {
                result -= currentTerm;
            }

            // If we've reached the end of the expression or the next operator, stop parsing
            if (i >= expression.length() || OPERATORS.contains(expression.charAt(i))) {
                break;
            }
        }

        return new Result(result, i);
    }

    // Helper method to evaluate multiplication and division (lower level of recursion)
    private static Result evaluateMulDiv(String expression, int startIndex) {
        double result = 1;
        double currentFactor = 0;
        char operator = '*';  // Start with multiplication
        int i = startIndex;

        // Handle the first factor (if it's a number or expression within parentheses)
        if (expression.charAt(i) == '(') {
            i++;  // Skip '('
            Result insideResult = evaluateAddSub(expression, i);
            currentFactor = insideResult.result;
            i = insideResult.index;
        } else {
            // Otherwise process multiplication or division
            Result factorResult = evaluateNumber(expression, i);
            currentFactor = factorResult.result;
            i = factorResult.index;
        }

        // Iterate through the rest of the multiplication/division expression
        while (i < expression.length()) {
            char ch = expression.charAt(i);

            if (ch == '*' || ch == '/') {
                operator = ch;
                i++;
            }

            // Evaluate next factor
            Result factorResult = evaluateNumber(expression, i);
            currentFactor = factorResult.result;
            i = factorResult.index;

            // Perform the current operation
            if (operator == '*') {
                result *= currentFactor;
            } else if (operator == '/') {
                if (currentFactor == 0) {
                    throw new ArithmeticException("Division by zero.");
                }
                result /= currentFactor;
            }

            // If we've reached the end of the expression or the next operator, stop parsing
            if (i >= expression.length() || OPERATORS.contains(expression.charAt(i))) {
                break;
            }
        }

        return new Result(result, i);
    }

    // Helper method to evaluate numbers (could be integers or floating-point numbers)
    private static Result evaluateNumber(String expression, int startIndex) {
        int i = startIndex;
        StringBuilder numberBuilder = new StringBuilder();

        // Read the number part (integer or floating-point)
        while (i < expression.length() && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
            numberBuilder.append(expression.charAt(i));
            i++;
        }

        // Convert the number to double
        if (numberBuilder.length() == 0) {
            throw new IllegalArgumentException("Invalid number at position " + startIndex);
        }

        double number = Double.parseDouble(numberBuilder.toString());
        return new Result(number, i);
    }

    // A utility class to store the result of the evaluation and the current index in the expression
    private static class Result {
        double result;
        int index;

        Result(double result, int index) {
            this.result = result;
            this.index = index;
        }
    }

    // Main function to test the parser
    public static void main(String[] args) {
        try {
            System.out.println(evaluateExpression("3 + 5 * 2")); // 13.0
            System.out.println(evaluateExpression("10 + 2 * 6")); // 22.0
            System.out.println(evaluateExpression("100 * 2 + 12")); // 212.0
            System.out.println(evaluateExpression("100 * ( 2 + 12 )")); // 1400.0
            System.out.println(evaluateExpression("3.5 + 4.5 * 2")); // 12.5
            System.out.println(evaluateExpression("10 / 2 + 3.5")); // 8.5
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
