package expressivo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdditionTest {

    @Test
    public void testToString() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression addition = new Addition(x, n5);
        
        assertEquals("(x + 5.0)", addition.toString());  // Ensure correct string formatting
    }

    @Test
    public void testEquals() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression addition1 = new Addition(x, n5);  // x + 5
        Expression addition2 = new Addition(n5, x);  // 5 + x (should not be equal)

        assertEquals(addition1, new Addition(x, n5));  // Same operands, same order
        assertNotEquals(addition1, addition2);  // Different order
    }

    @Test
    public void testHashCode() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression addition1 = new Addition(x, n5);
        Expression addition2 = new Addition(n5, x);

        assertEquals(addition1.hashCode(), new Addition(x, n5).hashCode());  // Same operands
        assertNotEquals(addition1.hashCode(), addition2.hashCode());  // Different operands (order matters)
    }
}
