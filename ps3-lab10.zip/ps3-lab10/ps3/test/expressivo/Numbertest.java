package expressivo;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Numbertest {

    @Test
    public void testToString() {
        Expression n = new Number(5.0);
        assertEquals("5.0", n.toString());
    }

    @Test
    public void testEquals() {
        Expression n1 = new Number(5.0);
        Expression n2 = new Number(5.0);
        Expression n3 = new Number(3.0);

        assertEquals(n1, n2);  // Same value
        assertNotEquals(n1, n3);  // Different value
    }

    @Test
    public void testHashCode() {
        Expression n1 = new Number(5.0);
        Expression n2 = new Number(5.0);
        Expression n3 = new Number(3.0);

        assertEquals(n1.hashCode(), n2.hashCode());  // Same value, same hash code
        assertNotEquals(n1.hashCode(), n3.hashCode());  // Different value, different hash code
    }
}
