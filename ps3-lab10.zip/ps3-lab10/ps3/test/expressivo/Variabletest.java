package expressivo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VariableTest {

    @Test
    public void testToString() {
        Expression v = new Variable("x");
        assertEquals("x", v.toString());
    }

    @Test
    public void testEquals() {
        Expression v1 = new Variable("x");
        Expression v2 = new Variable("x");
        Expression v3 = new Variable("y");

        assertEquals(v1, v2);  // Same variable name
        assertNotEquals(v1, v3);  // Different variable name
    }

    @Test
    public void testHashCode() {
        Expression v1 = new Variable("x");
        Expression v2 = new Variable("x");
        Expression v3 = new Variable("y");

        assertEquals(v1.hashCode(), v2.hashCode());  // Same variable, same hash code
        assertNotEquals(v1.hashCode(), v3.hashCode());  // Different variables, different hash code
    }
}

