package expressivo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MultiplicationTest {

    @Test
    public void testToString() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression multiplication = new Multiplication(n5, x);  // 5 * x
        
        assertEquals("(5.0 * x)", multiplication.toString());  // Ensure correct string formatting
    }

    @Test
    public void testEquals() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression multiplication1 = new Multiplication(n5, x);  // 5 * x
        Expression multiplication2 = new Multiplication(x, n5);  // x * 5 (should be different)

        assertEquals(multiplication1, new Multiplication(n5, x));  // Same operands
        assertNotEquals(multiplication1, multiplication2);  // Different order of operands
    }

    @Test
    public void testHashCode() {
        Expression x = new Variable("x");
        Expression n5 = new Number(5.0);
        Expression multiplication1 = new Multiplication(n5, x);
        Expression multiplication2 = new Multiplication(x, n5);

        assertEquals(multiplication1.hashCode(), new Multiplication(n5, x).hashCode());  // Same operands
        assertNotEquals(multiplication1.hashCode(), multiplication2.hashCode());  // Different order
    }
}

