package expressivo;

/**
 * Represents a variable in the expression.
 */
public class Variable implements Expression {
    private final String name;

    /**
     * Constructs a variable with the specified name.
     *
     * @param name the name of the variable
     */
    public Variable(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Variable variable = (Variable) obj;
        return name.equals(variable.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
