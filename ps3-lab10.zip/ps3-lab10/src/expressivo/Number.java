package expressivo;

/**
 * Represents a constant number in the expression.
 */
public class Number implements Expression {
    private final double value;

    /**
     * Constructs a number with the specified value.
     *
     * @param value the numeric value of the constant
     */
    public Number(double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Number number = (Number) obj;
        return Double.compare(number.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return Double.hashCode(value);
    }
}
