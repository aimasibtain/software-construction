package expressivo;

public class Differentiate extends Expression {

    private final Expression expression;
    private final String variable;

    public Differentiate(Expression expression, String variable) {
        this.expression = expression;
        this.variable = variable;
    }

    @Override
    public String toString() {
        return expression.toString();
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Differentiate that = (Differentiate) other;
        return expression.equals(that.expression) && variable.equals(that.variable);
    }

    @Override
    public int hashCode() {
        return 31 * expression.hashCode() + variable.hashCode();
    }

    @Override
    public Expression differentiate(String var) {
        return expression.differentiate(var);
    }
}

