package expressivo;

/**
 * Represents an addition operation between two expressions.
 */
public class Addition implements Expression {
    private final Expression left;  // Left operand
    private final Expression right; // Right operand

    /**
     * Constructs an addition operation with the specified operands.
     *
     * @param left the left operand
     * @param right the right operand
     */
    public Addition(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " + " + right.toString() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Addition addition = (Addition) obj;
        return left.equals(addition.left) && right.equals(addition.right);
    }

    @Override
    public int hashCode() {
        return 31 * left.hashCode() + right.hashCode();
    }
}
