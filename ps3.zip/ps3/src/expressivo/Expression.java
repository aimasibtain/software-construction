package expressivo;

public abstract class Expression {

    public abstract String toString();
    public abstract boolean equals(Object other);
    public abstract int hashCode();
    public abstract Expression differentiate(String var);

    // Number class
    public static class Number extends Expression {
        private final double value;

        public Number(double value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return Double.toString(value);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (other == null || getClass() != other.getClass()) return false;
            Number number = (Number) other;
            return Double.compare(number.value, value) == 0;
        }

        @Override
        public int hashCode() {
            return Double.hashCode(value);
        }

        @Override
        public Expression differentiate(String var) {
            return new Number(0); // The derivative of a constant is 0
        }
    }

    // Variable class
    public static class Variable extends Expression {
        private final String name;

        public Variable(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (other == null || getClass() != other.getClass()) return false;
            Variable variable = (Variable) other;
            return name.equals(variable.name);
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }

        @Override
        public Expression differentiate(String var) {
            if (this.name.equals(var)) {
                return new Number(1); // Derivative of var w.r.t. var is 1
            } else {
                return new Number(0); // Derivative of a different variable is 0
            }
        }
    }

    // BinaryOperation class
    public static class BinaryOperation extends Expression {
        private final Expression left;
        private final Expression right;
        private final String operator;

        public BinaryOperation(Expression left, Expression right, String operator) {
            this.left = left;
            this.right = right;
            this.operator = operator;
        }

        @Override
        public String toString() {
            return "(" + left.toString() + " " + operator + " " + right.toString() + ")";
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (other == null || getClass() != other.getClass()) return false;
            BinaryOperation that = (BinaryOperation) other;
            return left.equals(that.left) && right.equals(that.right) && operator.equals(that.operator);
        }

        @Override
        public int hashCode() {
            return 31 * left.hashCode() + 31 * right.hashCode() + operator.hashCode();
        }

        @Override
        public Expression differentiate(String var) {
            // Apply differentiation rules based on the operator
            switch (operator) {
                case "+":
                    // Derivative of (a + b) is a' + b'
                    return new BinaryOperation(left.differentiate(var), right.differentiate(var), "+");
                case "*":
                    // Derivative of (a * b) is (a' * b + a * b')
                    return new BinaryOperation(
                            new BinaryOperation(left.differentiate(var), right, "*"),
                            new BinaryOperation(left, right.differentiate(var), "*"),
                            "+"
                    );
                default:
                    throw new UnsupportedOperationException("Unknown operator: " + operator);
            }
        }
    }
}
