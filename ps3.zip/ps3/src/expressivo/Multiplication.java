package expressivo;

/**
 * Represents a multiplication operation between two expressions.
 */
public class Multiplication implements Expression {
    private final Expression left;  // Left operand
    private final Expression right; // Right operand

    /**
     * Constructs a multiplication operation with the specified operands.
     *
     * @param left the left operand
     * @param right the right operand
     */
    public Multiplication(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " * " + right.toString() + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Multiplication that = (Multiplication) obj;
        return left.equals(that.left) && right.equals(that.right);
    }

    @Override
    public int hashCode() {
        return 31 * left.hashCode() + right.hashCode();
    }
}
