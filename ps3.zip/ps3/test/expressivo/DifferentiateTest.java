package expressivo;

import static org.junit.Assert.*;

import org.junit.Test;

public class DifferentiateTest {

    @Test
    public void testConstantDifferentiation() {
        Expression constant = new Expression.Number(5);
        Expression derivative = constant.differentiate("x");
        assertEquals("0.0", derivative.toString());
    }

    @Test
    public void testVariableDifferentiation() {
        Expression variableX = new Expression.Variable("x");
        Expression derivative = variableX.differentiate("x");
        assertEquals("1.0", derivative.toString());

        Expression variableY = new Expression.Variable("y");
        derivative = variableX.differentiate("y");
        assertEquals("0.0", derivative.toString());
    }

    @Test
    public void testSumDifferentiation() {
        Expression expr = new Expression.BinaryOperation(
                new Expression.Variable("x"),
                new Expression.Number(5),
                "+"
        );
        Expression derivative = expr.differentiate("x");
        assertEquals("1.0 + 0.0", derivative.toString());
    }

    @Test
    public void testProductDifferentiation() {
        Expression expr = new Expression.BinaryOperation(
                new Expression.Variable("x"),
                new Expression.Variable("x"),
                "*"
        );
        Expression derivative = expr.differentiate("x");
        assertEquals("1.0 * x + x * 1.0", derivative.toString());
    }

    @Test
    public void testComplexExpressionDifferentiation() {
        Expression expr = new Expression.BinaryOperation(
                new Expression.BinaryOperation(new Expression.Variable("x"), new Expression.Number(5), "+"),
                new Expression.Variable("x"),
                "*"
        );
        Expression derivative = expr.differentiate("x");
        assertEquals("1.0 * x + (x + 5) * 1.0", derivative.toString());
    }

    @Test
    public void testNestedExpressionDifferentiation() {
        Expression expr = new Expression.BinaryOperation(
                new Expression.BinaryOperation(new Expression.BinaryOperation(new Expression.Variable("x"), new Expression.Variable("x"), "*"),
                        new Expression.Number(5), "+"),
                new Expression.Variable("x"),
                "*"
        );
        Expression derivative = expr.differentiate("x");
        assertEquals("(1.0 * x + x * 1.0) * x + (x * x + 5) * 1.0", derivative.toString());
    }

    @Test
    public void testProductRule() {
        Expression expr = new Expression.BinaryOperation(
                new Expression.BinaryOperation(new Expression.Variable("x"), new Expression.Number(2), "+"),
                new Expression.BinaryOperation(new Expression.Variable("x"), new Expression.Number(3), "+"),
                "*"
        );
        Expression derivative = expr.differentiate("x");
        assertEquals("(1.0 * (x + 3)) + ((x + 2) * 1.0)", derivative.toString());
    }
}
