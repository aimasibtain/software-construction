package expressivo;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExpressionTest {

    // Testing strategy:
    // - Valid inputs: test basic expressions like numbers, variables, addition, subtraction, multiplication, etc.
    // - Structural equality: test that expressions are equal when they represent the same mathematical structure.
    // - parse(): validate that parse correctly handles expressions.

    // Test for toString() method
    @Test
    public void testToString() {
        // Expression: 3 + 4
        Expression expr1 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+");
        assertEquals("(3.0 + 4.0)", expr1.toString());

        // Expression: 5 * x
        Expression expr2 = new Expression.BinaryOperation(new Expression.Number(5), new Expression.Variable("x"), "*");
        assertEquals("(5.0 * x)", expr2.toString());

        // Expression: (3 + 4) * x
        Expression expr3 = new Expression.BinaryOperation(
            new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+"),
            new Expression.Variable("x"),
            "*"
        );
        assertEquals("((3.0 + 4.0) * x)", expr3.toString());
    }

    // Test for equals() method
    @Test
    public void testEquals() {
        // Same expressions, should be equal
        Expression expr1 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+");
        Expression expr2 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+");
        assertTrue(expr1.equals(expr2));

        // Different expressions (different order), should not be equal
        Expression expr3 = new Expression.BinaryOperation(new Expression.Number(4), new Expression.Number(3), "+");
        assertFalse(expr1.equals(expr3));

        // Expressions with variables (should be equal)
        Expression expr4 = new Expression.BinaryOperation(new Expression.Variable("x"), new Expression.Number(3), "+");
        Expression expr5 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Variable("x"), "+");
        assertTrue(expr4.equals(expr5));
    }

    // Test for hashCode() method
    @Test
    public void testHashCode() {
        // Same expressions, should have the same hashCode
        Expression expr1 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+");
        Expression expr2 = new Expression.BinaryOperation(new Expression.Number(3), new Expression.Number(4), "+");
        assertEquals(expr1.hashCode(), expr2.hashCode());

        // Different expressions (should have different hashCodes)
        Expression expr3 = new Expression.BinaryOperation(new Expression.Number(4), new Expression.Number(3), "+");
        assertNotEquals(expr1.hashCode(), expr3.hashCode());
    }

    // Test for parse() method
    @Test
    public void testParse() throws Exception {
        // Expression: 3 + 4
        String input1 = "3 + 4";
        Expression parsedExpr1 = Expression.parse(input1);
        assertEquals("(3.0 + 4.0)", parsedExpr1.toString());

        // Expression: 5 * x
        String input2 = "5 * x";
        Expression parsedExpr2 = Expression.parse(input2);
        assertEquals("(5.0 * x)", parsedExpr2.toString());

        // Expression: (3 + 4) * x
        String input3 = "(3 + 4) * x";
        Expression parsedExpr3 = Expression.parse(input3);
        assertEquals("((3.0 + 4.0) * x)", parsedExpr3.toString());

        // Expression with more complex structure: 2 * (x + 3)
        String input4 = "2 * (x + 3)";
        Expression parsedExpr4 = Expression.parse(input4);
        assertEquals("(2.0 * (x + 3.0))", parsedExpr4.toString());
    }

    // Additional tests for invalid expressions (parse should throw an exception)
    @Test(expected = Exception.class)
    public void testParseInvalidExpression() throws Exception {
        // Invalid expression: missing operand
        String input = "3 +";
        Expression.parse(input);
    }

    @Test(expected = Exception.class)
    public void testParseInvalidExpression2() throws Exception {
        // Invalid expression: invalid character 'x' after number
        String input = "3 x";
        Expression.parse(input);
    }

    @Test(expected = Exception.class)
    public void testParseInvalidExpression3() throws Exception {
        // Invalid expression: missing operator
        String input = "(3 4)";
        Expression.parse(input);
    }

    @Test(expected = Exception.class)
    public void testParseInvalidExpression4() throws Exception {
        // Invalid expression: mismatched parentheses
        String input = "(3 + 4";
        Expression.parse(input);
    }

    @Test(expected = Exception.class)
    public void testParseInvalidExpression5() throws Exception {
        // Invalid expression: extra operator at the end
        String input = "3 + * 4";
        Expression.parse(input);
    }
}
