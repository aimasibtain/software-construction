package poet;

import java.io.StringReader;

public class GraphPoetTest {

    @Test
    public void testGraphConstruction() {
        String corpus = "To explore strange new worlds\nTo seek out new life and new civilizations";
        GraphPoet poet = new GraphPoet(new StringReader(corpus));

        assertTrue("Graph should contain 'to'", poet.graph().vertices().contains("to"));
        assertTrue("Graph should contain 'explore'", poet.graph().vertices().contains("explore"));
        assertEquals("Edge weight between 'to' and 'explore' should be 1",
                Integer.valueOf(1), poet.graph().sources("explore").get("to"));
    }

    @Test
    public void testPoeticTransformationWithBridgeWords() {
        String corpus = "To explore strange new worlds\nTo seek out new life and new civilizations";
        GraphPoet poet = new GraphPoet(new StringReader(corpus));
        String input = "To seek new worlds";
        String expected = "To seek out new worlds"; // "out" bridges "seek" and "new"
        assertEquals("Poetic transformation with bridge word failed", expected, poet.poem(input));
    }

    @Test
    public void testPoeticTransformationWithMultipleBridgeWords() {
        String corpus = "life is beautiful\nlife is strange\nbeautiful is strange";
        GraphPoet poet = new GraphPoet(new StringReader(corpus));
        String input = "life strange";
        String expected = "life is strange"; // "is" has the highest weight
        assertEquals("Poetic transformation with multiple bridge words failed", expected, poet.poem(input));
    }

    @Test
    public void testPoeticTransformationNoBridgeWords() {
        String corpus = "The quick brown fox";
        GraphPoet poet = new GraphPoet(new StringReader(corpus));
        String input = "Jumped over the lazy dog";
        assertEquals("Poetic transformation with no bridge words failed", input, poet.poem(input));
    }

    @Test
    public void testPoeticTransformationSingleWordInput() {
        String corpus = "Words are powerful";
        GraphPoet poet = new GraphPoet(new StringReader(corpus));
        String input = "Words";
        assertEquals("Single-word input should remain unchanged", input, poet.poem(input));
    }
}
