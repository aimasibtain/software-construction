package poet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;

public class GraphPoet {

    private final Graph<String> graph = Graph.empty();

    /**
     * Constructs a new GraphPoet using the provided corpus.
     * @param corpus the text corpus to derive the affinity graph from
     */
    public GraphPoet(Reader corpus) {
        try (BufferedReader reader = new BufferedReader(corpus)) {
            String line;
            String lastWord = null;

            while ((line = reader.readLine()) != null) {
                String[] words = line.toLowerCase().split("\\W+");
                for (String word : words) {
                    if (!word.isEmpty()) {
                        graph.add(word);
                        if (lastWord != null) {
                            int currentWeight = graph.set(lastWord, word, 0);
                            graph.set(lastWord, word, currentWeight + 1);
                        }
                        lastWord = word;
                    }
                }
                lastWord = null; // Reset after each line
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read corpus", e);
        }
    }

    /**
     * Generates a poem by transforming the input text poetically.
     * @param input the input text
     * @return the poetically transformed text
     */
    public String poem(String input) {
        String[] words = input.split("\\s+");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < words.length - 1; i++) {
            String word1 = words[i].toLowerCase();
            String word2 = words[i + 1].toLowerCase();

            // Add the current word
            result.append(words[i]).append(" ");

            // Find the bridge word
            Map<String, Integer> targets = graph.targets(word1);
            String bridge = null;
            int maxWeight = 0;

            for (Map.Entry<String, Integer> entry : targets.entrySet()) {
                if (entry.getKey().equals(word2)) continue;
                if (graph.sources(word2).getOrDefault(entry.getKey(), 0) > 0
                        && entry.getValue() > maxWeight) {
                    bridge = entry.getKey();
                    maxWeight = entry.getValue();
                }
            }

            // Add the bridge word if found
            if (bridge != null) {
                result.append(bridge).append(" ");
            }
        }

        // Add the last word
        result.append(words[words.length - 1]);
        return result.toString();
    }

    /**
     * @return the word affinity graph used by this poet
     */
    public Graph<String> graph() {
        return graph;
    }
}
